const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");
const app = express();
const dotenv = require('dotenv');
dotenv.config();

app.use(express.json());
app.use(cors({
    origin: '*', 
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    }
});

app.post("/server", async (req, res) => {
    const { email, nome } = req.body;

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Confirmação de Cadastro",
        text: `Olá ${nome}, obrigado por se cadastrar! Você receberá atualizações em breve.`
    };

    try {
        await transporter.sendMail(mailOptions);  // Corrigido de 'sendMail' para 'sendMail'
        res.json({ message: "E-mail enviado com sucesso!" });
    } catch (error) {
        res.status(500).json({ error: "Erro ao enviar e-mail." });
    }
});

// Configuração para ouvir em qualquer IP (0.0.0.0)
app.listen(3000, '0.0.0.0', () => {
    console.log("Servidor rodando na porta 3000");
});
